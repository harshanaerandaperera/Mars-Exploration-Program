create trigger INCREMENTOBJECTIVEIDANDRETURN
  before insert
  on OBJECTIVE
  for each row
  DECLARE
  BEGIN
    :new.ObjectiveID := ObjectiveID_auto_increment.NEXTVAL;
  END;
/

