create PACKAGE mypkg IS
  TYPE numtype IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
  PROCEDURE updateMap(rid IN NUMBER,traversalP IN VARCHAR2 ,traversalDistances IN numtype);
END;
/

create PACKAGE BODY mypkg IS
  PROCEDURE updateMap(rid IN NUMBER,traversalP IN VARCHAR2, traversalDistances IN numtype) IS
    totalDistance NUMBER;
    BEGIN
      totalDistance:=0;
      FOR i IN 1..traversalDistances.COUNT LOOP
        totalDistance := traversalDistances(i)+totalDistance;
      END LOOP;

      UPDATE RoverMap
      SET TRAVERSALPATH = traversalP,TRAVERSALDISTANCE = totalDistance
      WHERE ROVERID=rid;
    END;
END;
/

