create PROCEDURE getCreatedRover(RID IN int, RName OUT VARCHAR2,RWeight OUT NUMBER,RHeight OUT NUMBER,RLength OUT NUMBER,RLaunchedDate OUT VARCHAR2,RLandedDate OUT VARCHAR2,RLandedPlace OUT VARCHAR2,RPowerType OUT VARCHAR2,RComputerID OUT int,ROperatingSystem OUT VARCHAR2,RRam OUT NUMBER,RMemoryCapacity OUT NUMBER) AS
  BEGIN
    SELECT RoverName,Weight,Height,Length,LaunchedDate,LandedDate,LandedPlace,PowerType INTO RName,RWeight,RHeight,RLength,RLaunchedDate,RLandedDate,RLandedPlace,RPowerType FROM Rover WHERE RoverID = RID;
    SELECT ComputerID,OperatingSystem,Ram,MemoryCapacity INTO RComputerID,ROperatingSystem,RRam,RMemoryCapacity FROM RoverComputer WHERE RoverID = RID;
  END;
/

