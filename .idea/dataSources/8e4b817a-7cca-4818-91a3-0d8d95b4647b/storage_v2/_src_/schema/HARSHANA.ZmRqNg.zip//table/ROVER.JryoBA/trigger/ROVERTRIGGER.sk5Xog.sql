create trigger ROVERTRIGGER
  before insert
  on ROVER
  for each row
  DECLARE
  BEGIN
    :new.RoverID := RoverID_auto_increment.NEXTVAL;
  END;
/

