create FUNCTION getTraversalDistance(D_A IN Distance_Array )
  RETURN NUMBER
IS
  totalDistance NUMBER;
  BEGIN
    totalDistance:=0;
    FOR i IN 1..D_A.COUNT LOOP
      totalDistance := D_A(i)+totalDistance;
    END LOOP;

    UPDATE ROVERMAP
    SET TraversalDistance = totalDistance
    WHERE RoverID = 1;

    RETURN totalDistance;
  END;
/

