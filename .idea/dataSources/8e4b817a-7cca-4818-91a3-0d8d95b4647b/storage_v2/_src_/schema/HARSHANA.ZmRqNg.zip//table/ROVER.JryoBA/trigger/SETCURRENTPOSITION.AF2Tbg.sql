create trigger SETCURRENTPOSITION
  after insert
  on ROVER
  DECLARE
    LP VARCHAR2(100);
    LastRoverID int;
  BEGIN
    SELECT MAX(RoverID) INTO LastRoverID from Rover;
    SELECT LandedPlace INTO LP FROM Rover WHERE RoverID=LastRoverID;
    INSERT INTO RoverMap (MapID,CurrentPosition,RoverID) VALUES(MAPID_AUTO_INCREMENT.NEXTVAL,LP,LastRoverID);
  END;
/

