create trigger ROVERDATEVALIDATE
  before insert
  on ROVER
  for each row
  BEGIN
    IF :NEW.LANDEDDATE <= :NEW.LAUNCHEDDATE
    THEN
      ROLLBACK ;
    END IF;
  END;
/

